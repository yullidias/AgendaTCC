<?php $__env->startSection('titulo','Pré Cadastro'); ?>

<?php $__env->startSection('camposnavbar'); ?>
<li><a href="<?php echo e(route('listar_alunos')); ?>">Aluno</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<br><br>
<form action="<?php echo e(route('salvar_pre_cadastro_aluno')); ?>" method="post">
	<?php echo e(csrf_field()); ?>

	<div class='form-group'>
		<label>Matricula</label>
		<input type='text' class='form-control' name='matricula' required>
	</div>

	<br><label>Matéria</label>
	<div class="radio">
	  <label>
	    <input type="radio" name="materia" value="1" checked> TCC1
	  </label>
	</div>
	<div class="radio">
	  <label>
	    <input type="radio" name="materia" value="1"> TCC2
	  </label>
	</div>
		
	<br><input type='submit' class='btn btn-default' value='Cadastrar'>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>